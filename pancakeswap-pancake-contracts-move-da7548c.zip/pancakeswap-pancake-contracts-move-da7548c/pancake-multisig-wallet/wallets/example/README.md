# Example Multisig Wallet
Just copy this folder and follow the TODO steps in the `sources/example.move` to
implement your own multisig wallet.
