# MasterChef

## Description

New MasterChef in Aptos
